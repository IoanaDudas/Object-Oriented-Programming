#include "Veggie.h"

string Veggie::getFamily() const
{
    return this->family;
}

string Veggie::getName() const
{
    return this->name;
}

string Veggie::getParts() const
{
    return this->parts;
}
