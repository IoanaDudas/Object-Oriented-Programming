#pragma once

void testDate();

void testTape();

void testDynamicVector();

void testVirtualRepository();

void testInMemoryRepository();

void testRepositoryHelper();

void testService();

void testFileRepository();